<?php

namespace App\Http\Controllers;

use App\Models\Fournisseur;
use Illuminate\Http\Request;

class FournisseurController extends Controller
{
    public function index()
    {
        return Fournisseur::all();
    }

    public function store(Request $request)
    {
        $fournisseur = Fournisseur::create($request->all());
        return response()->json($fournisseur, 201);
    }

    public function show($id)
    {
        return Fournisseur::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $fournisseur = Fournisseur::findOrFail($id);
        $fournisseur->update($request->all());
        return response()->json($fournisseur, 200);
    }

    public function destroy($id)
    {
        Fournisseur::findOrFail($id)->delete();
        return response()->json(null, 204);
    }
}
