<?php

namespace App\Http\Controllers;

use App\Models\Domaine;
use Illuminate\Http\Request;

class DomaineController extends Controller
{
    public function index()
    {
        return Domaine::all();
    }

    public function store(Request $request)
    {
        $domaine = Domaine::create($request->all());
        return response()->json($domaine, 201);
    }

    public function show($id)
    {
        return Domaine::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $domaine = Domaine::findOrFail($id);
        $domaine->update($request->all());
        return response()->json($domaine, 200);
    }

    public function destroy($id)
    {
        Domaine::findOrFail($id)->delete();
        return response()->json(null, 204);
    }
}
