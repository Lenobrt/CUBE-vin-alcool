<?php

namespace App\Http\Controllers;

use App\Models\Famille;
use Illuminate\Http\Request;

class FamilleController extends Controller
{
    public function index()
    {
        return Famille::all();
    }

    public function store(Request $request)
    {
        $famille = Famille::create($request->all());
        return response()->json($famille, 201);
    }

    public function show($id)
    {
        return Famille::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $famille = Famille::findOrFail($id);
        $famille->update($request->all());
        return response()->json($famille, 200);
    }

    public function destroy($id)
    {
        Famille::findOrFail($id)->delete();
        return response()->json(null, 204);
    }
}
