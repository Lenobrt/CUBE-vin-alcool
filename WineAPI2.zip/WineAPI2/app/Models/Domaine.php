<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Domaine extends Model
{
    protected $fillable = ['nom', 'adresse', 'numero', 'idfournisseur'];

    public function fournisseur()
    {
        return $this->belongsTo(Fournisseur::class, 'idfournisseur');
    }

    public function articles()
    {
        return $this->hasMany(Article::class, 'iddomaine');
    }
}
