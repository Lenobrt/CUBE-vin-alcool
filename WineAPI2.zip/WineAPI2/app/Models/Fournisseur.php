<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Fournisseur extends Model
{
    protected $fillable = ['nom', 'adresse', 'numero', 'idarticle'];

    public function article()
    {
        return $this->belongsTo(Article::class, 'idarticle');
    }
}
