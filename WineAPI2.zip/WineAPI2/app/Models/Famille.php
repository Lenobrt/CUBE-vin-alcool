<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Famille extends Model
{
    protected $fillable = ['nom', 'description'];

    public function articles()
    {
        return $this->hasMany(Article::class, 'idfamille');
    }
}
