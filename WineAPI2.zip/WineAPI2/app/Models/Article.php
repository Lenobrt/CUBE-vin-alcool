<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    protected $fillable = [
        'nom', 'prixunite', 'prixpack', 'paysproduction', 'regionproduction',
        'anneeproduction', 'quantite', 'quantiteminimum', 'idfamille', 'iddomaine'
    ];

    public function famille()
    {
        return $this->belongsTo(Famille::class, 'idfamille');
    }

    public function domaine()
    {
        return $this->belongsTo(Domaine::class, 'iddomaine');
    }
}
