<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\FournisseurController;
use App\Http\Controllers\FamilleController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\DomaineController;

Route::apiResource('clients', ClientController::class);
Route::apiResource('fournisseurs', FournisseurController::class);
Route::apiResource('familles', FamilleController::class);
Route::apiResource('articles', ArticleController::class);
Route::apiResource('domaines', DomaineController::class);

Route::get('recipe', 'App\Http\Controllers\RecipeController@index');

/*
Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});*/
