<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFournisseursTable extends Migration
{
public function up()
{
Schema::create('fournisseurs', function (Blueprint $table) {
$table->id();
$table->string('nom', 50);
$table->string('adresse', 50);
$table->string('numero', 50);
$table->unsignedBigInteger('idarticle');
$table->timestamps();
});
}

public function down()
{
Schema::dropIfExists('fournisseurs');
}
}
