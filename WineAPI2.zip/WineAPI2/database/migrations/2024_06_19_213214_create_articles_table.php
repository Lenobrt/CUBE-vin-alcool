<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateArticlesTable extends Migration
{
    public function up()
    {
        Schema::create('articles', function (Blueprint $table) {
            $table->id();
            $table->string('nom', 50);
            $table->integer('prixunite');
            $table->integer('prixpack');
            $table->string('paysproduction', 50);
            $table->string('regionproduction', 50);
            $table->integer('anneeproduction');
            $table->integer('quantite');
            $table->integer('quantiteminimum');
            $table->unsignedBigInteger('idfamille');
            $table->unsignedBigInteger('iddomaine');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('articles');
    }
}
