<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToArticlesTable extends Migration
{
    public function up()
    {
        Schema::table('articles', function (Blueprint $table) {
            $table->foreign('idfamille')->references('id')->on('familles');
            $table->foreign('iddomaine')->references('id')->on('domaines');
        });
    }

    public function down()
    {
        Schema::table('articles', function (Blueprint $table) {
            $table->dropForeign(['idfamille']);
            $table->dropForeign(['iddomaine']);
        });
    }
}
